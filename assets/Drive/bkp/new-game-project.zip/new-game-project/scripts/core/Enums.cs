namespace Game.Core
{
    public enum LogLevel
    {
        DEBUG,

        INFO,

        WARNING,
        
        ERROR
    }
}